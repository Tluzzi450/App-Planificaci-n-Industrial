# Planificador Académico — Ingeniería Industrial · UTN FRH

Correlativas, armado de horarios, agenda de exámenes, calendario académico,
mapa de correlatividades y simulador de carrera para **Ingeniería Industrial**
en la UTN Facultad Regional Haedo (Plan 2023, Ord. 1908/2141).

> Herramienta **no oficial**, sin relación con los sistemas de la Facultad.
> Confirmá siempre inscripciones y correlatividades en Autogestión.

---

## Para estudiantes

**Entrar:** `https://TU-USUARIO.github.io/TU-REPO/`

**Instalarla en el celular** (queda como una app, con ícono propio y anda sin internet):

- **Android / Chrome** — menú ⋮ → *Instalar aplicación* (o *Agregar a pantalla principal*).
- **iPhone / Safari** — botón Compartir → *Agregar a pantalla de inicio*.
  En iPhone tiene que ser **Safari**: desde Chrome el botón no aparece.
- **Computadora** — el ícono de instalar aparece a la derecha de la barra de direcciones.

**Sobre tus datos.** Todo tu progreso se guarda en tu propio dispositivo. Si iniciás
sesión, además se sincroniza entre tu celular y tu computadora. El pie de página
siempre dice en cuál de los dos casos estás. La contraseña de la app **no es la de
Autogestión**: es una cuenta aparte, sólo para esto.

Aunque no quieras cuenta, podés llevarte tus datos con **⬇ Exportar**, que baja un
archivo JSON, y volver a cargarlo en otro dispositivo con **⬆ Importar**.

---

## Publicarlo (esto lo hace quien administra el repositorio)

### 1. Subir los archivos

Creá un repositorio **público** en GitHub y subí todo el contenido de esta carpeta
en la raíz. Debería quedar así:

```
index.html                 la app entera, en un solo archivo
manifest.webmanifest       para que se pueda instalar
sw.js                      caché offline y actualizaciones
icons/                     íconos de la app
config.js.ejemplo          plantilla para las cuentas (ver paso 3)
firestore.rules            reglas de seguridad de la base
.nojekyll                  evita que GitHub procese el sitio de más
```

### 2. Encender GitHub Pages

En el repositorio: **Settings → Pages → Source: Deploy from a branch**, rama `main`,
carpeta `/ (root)`, **Save**. A los pocos minutos el sitio queda en
`https://TU-USUARIO.github.io/TU-REPO/`.

Con esto ya funciona todo: la app, la instalación en el celular y el uso sin internet.
Cada estudiante guarda su progreso en su dispositivo. **Si eso te alcanza, terminaste acá.**

### 3. Cuentas y sincronización (opcional)

Sólo hace falta si querés que cada estudiante tenga una cuenta y encuentre su progreso
al cambiar de dispositivo. Se usa Firebase, que tiene un plan gratuito de sobra para esto.

1. En [console.firebase.google.com](https://console.firebase.google.com) creá un proyecto.
2. Agregá una **app web** (el ícono `</>`). Al final te muestra un bloque `firebaseConfig`.
3. **Authentication → Sign-in method**: habilitá **Correo electrónico/contraseña** y,
   si querés, **Google**.
4. **Authentication → Settings → Dominios autorizados**: agregá `TU-USUARIO.github.io`.
   Sin este paso el inicio de sesión falla, y el error no dice por qué.
5. **Firestore Database**: creá la base en modo producción.
6. **Firestore → Reglas**: pegá el contenido de `firestore.rules` y publicá.
   **Este paso no es opcional.** Sin esas reglas, cualquiera podría leer el progreso
   de todos los estudiantes.
7. Copiá `config.js.ejemplo` como `config.js`, pegá adentro tu `firebaseConfig` y subilo.

Cuando `config.js` está publicado, aparece la pantalla de inicio de sesión (con la
opción de seguir sin cuenta) y el botón *☁ Sincronizar* en el encabezado.

> **¿Las claves de `config.js` son secretas?** No. La `apiKey` de Firebase para web
> identifica al proyecto, no autoriza nada por sí sola; Google la publica en su propia
> documentación. Lo que protege los datos son los pasos 4 y 6. No pongas ahí ninguna
> clave de servicio ni credencial de administrador.

---

## Publicar una actualización

1. Reemplazá `index.html` (y lo que haya cambiado).
2. Abrí `sw.js` y cambiá la línea `const VERSION = "…"` por la fecha de hoy.

Ese segundo paso importa: si no cambia, los celulares que ya tienen la app instalada
pueden seguir mostrando la versión vieja. Al cambiarlo, la próxima vez que abran la
app con internet les aparece un aviso de *Actualizar*.

---

## Cómo está armado

`index.html` es autocontenido: el plan de estudios, las correlativas, los horarios
2026 y el calendario académico van adentro del archivo. No hay servidor propio ni
backend. Se puede descargar suelto y abrir con doble clic: funciona igual, sin cuentas.

Sólo se conecta afuera para tres cosas, todas opcionales:
la tipografía (Google Fonts), el SDK de Firebase si alguien inicia sesión, y nada más.
Los horarios se actualizan pegando a mano el código de la web de la Facultad, desde
la propia app — no se descargan solos.

## Fuentes de los datos

- Ordenanzas UTN **1908** y **2141** (plan 2023) — plan de estudios y correlatividades.
- Horarios oficiales FRH (`horarios.frh.utn.edu.ar`) — comisiones y bandas horarias 2026.
- **Res. CD 476/2024** — calendario académico 2026 y comienzo de 2027.
